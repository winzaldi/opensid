<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="--mx-2 --mt-4 --mb-4 --text-center">
	<img src="<?= base_url($this->theme_folder.'/'.$this->theme .'/assets/images/empty.svg') ?>" alt="" class="content__image --mx-auto --mb-10 --mt-4" style="max-width: 50%">
	<strong>Belum ada artikel yang dituliskan dalam <?= $title ?></strong>
	<p>Silakan kunjungi kembali dalam waktu dekat</p>
</div>